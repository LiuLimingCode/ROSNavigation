# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/zn/racecar/src/rf2o_laser_odometry/include".split(';') if "/home/zn/racecar/src/rf2o_laser_odometry/include" != "" else []
PROJECT_CATKIN_DEPENDS = "nav_msgs;roscpp;sensor_msgs;std_msgs;tf".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-llaser_odometry".split(';') if "-llaser_odometry" != "" else []
PROJECT_NAME = "rf2o_laser_odometry"
PROJECT_SPACE_DIR = "/home/zn/racecar/src/rf2o_laser_odometry/cmake-build-debug/devel"
PROJECT_VERSION = "1.0.0"
